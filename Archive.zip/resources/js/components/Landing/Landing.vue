<template>
    <div>
        <grid-component></grid-component>
    </div>
</template>
<script>
export default {
    name: 'landing-app',
}
</script>