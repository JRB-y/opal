<template>
    <div class="container">
        <h3>
            Dashboard
            <small class="text-muted">Welcome </small>
        </h3>
        <b-card-group deck>
            <b-card border-variant="light" header="Products" class="text-center">
                <b-card-text><i class="fa fa-gem"></i> 4 </b-card-text>
            </b-card>
            <b-card border-variant="light" header="Users" class="text-center">
                <b-card-text><i class="fa fa-user"></i> 120 </b-card-text>
            </b-card>
        </b-card-group>

    </div>
</template>

<script>
    export default {
        name: "Dashboard"
    }
</script>

<style scoped>

</style>